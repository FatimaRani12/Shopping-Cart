﻿using System;
using System.Collections.Generic;
using System.IO;

class Product
{
    public string ProductID { get; set; }
    public string ProductName { get; set; }
    public double Price { get; set; }

    public Product(string productId, string productName, double price)
    {
        ProductID = productId;
        ProductName = productName;
        Price = price;
    }
}

class CartItem
{
    public Product Product { get; set; }
    public int Quantity { get; set; }

    public CartItem(Product product, int quantity)
    {
        Product = product;
        Quantity = quantity;
    }
}

class ShoppingCart
{
    public static List<Product> products = new List<Product>();
    public static Dictionary<string, CartItem> cart = new Dictionary<string, CartItem>();
    public static double salesTax = 0.08;
    public static DateTime cartCreationTime;
    public static TimeSpan cartExpirationTime = TimeSpan.FromMinutes(30);
    public static string cartFilePath = "cart.txt";
    public static Random random = new Random();

    static void Main(string[] args)
    {
        try
        {
            InitializeProducts();
            LoadCartFromFile();
            cartCreationTime = DateTime.Now;
            bool isRunning = true;

            while (isRunning)
            {
                Console.Clear();
                Console.WriteLine("Welcome to the Shopping Cart System");
                Console.WriteLine("-----------------------------------");
                Console.WriteLine("1. Add Product to Cart");
                Console.WriteLine("2. Remove Product from Cart");
                Console.WriteLine("3. View Cart");
                Console.WriteLine("4. Manage Item Quantity");
                Console.WriteLine("5. Checkout");
                Console.WriteLine("6. Exit");
                Console.Write("\nPlease select an option: ");

                string? option = Console.ReadLine()?.Trim();
                if (string.IsNullOrEmpty(option)) continue;

                switch (option)
                {
                    case "1":
                        AddProductToCart();
                        break;
                    case "2":
                        RemoveProductFromCart();
                        break;
                    case "3":
                        ViewCart();
                        break;
                    case "4":
                        ManageItemQuantity();
                        break;
                    case "5":
                        Checkout();
                        break;
                    case "6":
                        isRunning = false;
                        break;
                    default:
                        Console.WriteLine("Invalid option. Please try again.");
                        Pause();
                        break;
                }

                if (IsCartExpired())
                {
                    Console.WriteLine("\nYour cart has expired! All items removed.");
                    cart.Clear();
                    SaveCartToFile();
                    cartCreationTime = DateTime.Now;
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"An error occurred: {ex.Message}");
        }
    }

    static void InitializeProducts()
    {
        try
        {
            products.Add(new Product("P001", "Laptop", 999.99));
            products.Add(new Product("P002", "Smartphone", 499.99));
            products.Add(new Product("P003", "Tablet", 299.99));
            products.Add(new Product("P004", "Headphones", 149.99));
            products.Add(new Product("P005", "Smartwatch", 199.99));
            products.Add(new Product("P006", "Monitor", 249.99));
            products.Add(new Product("P007", "Keyboard", 49.99));
            products.Add(new Product("P008", "Mouse", 29.99));
            products.Add(new Product("P009", "Printer", 129.99));
            products.Add(new Product("P010", "Scanner", 89.99));
            products.Add(new Product("P011", "Camera", 399.99));
            products.Add(new Product("P012", "Speakers", 59.99));
            products.Add(new Product("P013", "External Hard Drive", 79.99));
            products.Add(new Product("P014", "USB Flash Drive", 19.99));
            products.Add(new Product("P015", "Power Bank", 49.99));
            products.Add(new Product("P016", "Router", 99.99));
            products.Add(new Product("P017", "Webcam", 69.99));
            products.Add(new Product("P018", "Microphone", 89.99));
            products.Add(new Product("P019", "VR Headset", 299.99));
            products.Add(new Product("P020", "Gaming Console", 499.99));
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error initializing products: {ex.Message}");
        }
    }

    static void AddProductToCart()
    {
        try
        {
            Console.Clear();
            Console.WriteLine("Available Products:");
            foreach (var product in products)
            {
                Console.WriteLine($"{product.ProductID} - {product.ProductName}: ${product.Price}");
            }

            Console.Write("\nEnter the Product ID to add to cart: ");
            string? productId = Console.ReadLine()?.Trim();

            if (string.IsNullOrEmpty(productId))
            {
                Console.WriteLine("Product ID cannot be empty.");
                Pause();
                return;
            }

            Product? selectedProduct = products.Find(p => p.ProductID == productId);
            if (selectedProduct != null)
            {
                Console.Write("Enter quantity: ");
                if (int.TryParse(Console.ReadLine(), out int quantity) && quantity > 0)
                {
                    if (cart.ContainsKey(productId))
                    {
                        cart[productId].Quantity += quantity;
                    }
                    else
                    {
                        cart.Add(productId, new CartItem(selectedProduct, quantity));
                    }
                    SaveCartToFile();
                    Console.WriteLine($"{quantity} {selectedProduct.ProductName}(s) added to your cart.");
                }
                else
                {
                    Console.WriteLine("Invalid quantity. Please enter a positive integer.");
                }
            }
            else
            {
                Console.WriteLine("Product not found. Please try again.");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error adding product to cart: {ex.Message}");
        }
        Pause();
    }

    static void RemoveProductFromCart()
    {
        try
        {
            Console.Clear();
            if (cart.Count == 0)
            {
                Console.WriteLine("Your cart is empty.");
                Pause();
                return;
            }

            Console.WriteLine("Products in your cart:");
            foreach (var item in cart)
            {
                Console.WriteLine($"{item.Key} - {item.Value.Product.ProductName}: {item.Value.Quantity}");
            }

            Console.Write("\nEnter the Product ID to remove from cart: ");
            string? productId = Console.ReadLine()?.Trim();

            if (string.IsNullOrEmpty(productId))
            {
                Console.WriteLine("Product ID cannot be empty.");
                Pause();
                return;
            }

            if (cart.ContainsKey(productId))
            {
                cart.Remove(productId);
                SaveCartToFile();
                Console.WriteLine("Product removed from cart.");
            }
            else
            {
                Console.WriteLine("Product not found in cart.");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error removing product from cart: {ex.Message}");
        }
        Pause();
    }

    static void ViewCart()
    {
        try
        {
            Console.Clear();
            if (cart.Count == 0)
            {
                Console.WriteLine("Your cart is empty.");
            }
            else
            {
                Console.WriteLine("Your Cart:");
                double total = 0;
                foreach (var item in cart)
                {
                    double itemTotal = item.Value.Quantity * item.Value.Product.Price;
                    total += itemTotal;
                    Console.WriteLine($"{item.Value.Product.ProductName} - {item.Value.Quantity} @ ${item.Value.Product.Price} = ${itemTotal}");
                }

                double discountAmount = 0;
                foreach (var item in cart)
                {
                    double productDiscount = random.Next(5, 21) / 100.0;
                    double productDiscountAmount = item.Value.Product.Price * item.Value.Quantity * productDiscount;
                    discountAmount += productDiscountAmount;

                    Console.WriteLine($"Discount on {item.Value.Product.ProductName} ({productDiscount * 100}%): -${productDiscountAmount}");
                }

                double taxAmount = (total - discountAmount) * salesTax;
                double grandTotal = (total - discountAmount) + taxAmount;

                Console.WriteLine($"\nSubtotal: ${total}");
                Console.WriteLine($"Total Discount: -${discountAmount}");
                Console.WriteLine($"Sales Tax (8%): +${taxAmount}");
                Console.WriteLine($"Grand Total: ${grandTotal}");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error viewing cart: {ex.Message}");
        }
        Pause();
    }

    static void ManageItemQuantity()
    {
        try
        {
            Console.Clear();
            if (cart.Count == 0)
            {
                Console.WriteLine("Your cart is empty.");
                Pause();
                return;
            }

            Console.WriteLine("Products in your cart:");
            foreach (var item in cart)
            {
                Console.WriteLine($"{item.Key} - {item.Value.Product.ProductName}: {item.Value.Quantity}");
            }

            Console.Write("\nEnter the Product ID to update quantity: ");
            string? productId = Console.ReadLine()?.Trim();

            if (string.IsNullOrEmpty(productId))
            {
                Console.WriteLine("Product ID cannot be empty.");
                Pause();
                return;
            }

            if (cart.ContainsKey(productId))
            {
                Console.Write("Enter new quantity: ");
                if (int.TryParse(Console.ReadLine(), out int newQuantity) && newQuantity > 0)
                {
                    cart[productId].Quantity = newQuantity;
                    SaveCartToFile();
                    Console.WriteLine($"Quantity for {cart[productId].Product.ProductName} updated to {newQuantity}.");
                }
                else
                {
                    Console.WriteLine("Invalid quantity. Please enter a positive integer.");
                }
            }
            else
            {
                Console.WriteLine("Product not found in cart.");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error managing item quantity: {ex.Message}");
        }
        Pause();
    }

    static void Checkout()
    {
        try
        {
            Console.Clear();
            if (cart.Count == 0)
            {
                Console.WriteLine("Your cart is empty. Please add items before checking out.");
                Pause();
                return;
            }

            Console.WriteLine("Checkout Summary:");
            double total = 0;
            double discountAmount = 0;

            foreach (var item in cart)
            {
                double itemTotal = item.Value.Quantity * item.Value.Product.Price;
                total += itemTotal;

                double productDiscount = random.Next(5, 21) / 100.0;
                double productDiscountAmount = item.Value.Product.Price * item.Value.Quantity * productDiscount;
                discountAmount += productDiscountAmount;

                Console.WriteLine($"{item.Value.Product.ProductName} - {item.Value.Quantity} @ ${item.Value.Product.Price} = ${itemTotal}");
                Console.WriteLine($"Discount on {item.Value.Product.ProductName} ({productDiscount * 100}%): -${productDiscountAmount}");
            }

            double taxAmount = (total - discountAmount) * salesTax;
            double grandTotal = (total - discountAmount) + taxAmount;

            Console.WriteLine($"\nSubtotal: ${total}");
            Console.WriteLine($"Total Discount: -${discountAmount}");
            Console.WriteLine($"Sales Tax (8%): +${taxAmount}");
            Console.WriteLine($"Grand Total: ${grandTotal}");

            Console.Write("\nProceed with checkout? (y/n): ");
            string? confirmation = Console.ReadLine()?.Trim().ToLower();

            if (confirmation == "y")
            {
                cart.Clear(); // Clear the cart after checkout
                SaveCartToFile(); // Save the empty cart to file
                Console.WriteLine("Thank you for your purchase! Your order has been placed.");
            }
            else
            {
                Console.WriteLine("Checkout canceled.");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error during checkout: {ex.Message}");
        }
        Pause();
    }


    static void Pause()
    {
        Console.WriteLine("\nPress any key to continue...");
        Console.ReadKey();
    }

    static bool IsCartExpired()
    {
        return DateTime.Now - cartCreationTime > cartExpirationTime;
    }

    static void LoadCartFromFile()
    {
        if (File.Exists(cartFilePath))
        {
            var lines = File.ReadAllLines(cartFilePath);
            foreach (var line in lines)
            {
                var parts = line.Split(',');
                if (parts.Length == 3 && double.TryParse(parts[1], out double price) && int.TryParse(parts[2], out int quantity))
                {
                    var product = new Product(parts[0], parts[0], price);
                    cart.Add(parts[0], new CartItem(product, quantity));
                }
                else
                {
                    Console.WriteLine($"Invalid line in cart file: {line}. Skipping.");
                }
            }
        }
    }

    static void SaveCartToFile()
    {
        try
        {
            using (StreamWriter writer = new StreamWriter(cartFilePath))
            {
                foreach (var item in cart)
                {
                    writer.WriteLine($"{item.Key},{item.Value.Product.Price},{item.Value.Quantity}");
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error saving cart to file: {ex.Message}");
        }
    }
}